﻿namespace tachnen01
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.picBox_Hinhgoc = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.picBox_RED = new System.Windows.Forms.PictureBox();
			this.label4 = new System.Windows.Forms.Label();
			this.picBox_GREEN = new System.Windows.Forms.PictureBox();
			this.label5 = new System.Windows.Forms.Label();
			this.picBox_BLUE = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.picBox_Hinhgoc)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.picBox_RED)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.picBox_GREEN)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.picBox_BLUE)).BeginInit();
			this.SuspendLayout();
			// 
			// picBox_Hinhgoc
			// 
			this.picBox_Hinhgoc.Location = new System.Drawing.Point(65, 29);
			this.picBox_Hinhgoc.Name = "picBox_Hinhgoc";
			this.picBox_Hinhgoc.Size = new System.Drawing.Size(512, 512);
			this.picBox_Hinhgoc.TabIndex = 0;
			this.picBox_Hinhgoc.TabStop = false;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(62, 9);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(67, 17);
			this.label2.TabIndex = 1;
			this.label2.Text = "Hình Gốc";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(672, 9);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(92, 17);
			this.label3.TabIndex = 3;
			this.label3.Text = "Hình màu đỏ ";
			// 
			// picBox_RED
			// 
			this.picBox_RED.Location = new System.Drawing.Point(675, 29);
			this.picBox_RED.Name = "picBox_RED";
			this.picBox_RED.Size = new System.Drawing.Size(512, 512);
			this.picBox_RED.TabIndex = 2;
			this.picBox_RED.TabStop = false;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(62, 547);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(78, 17);
			this.label4.TabIndex = 5;
			this.label4.Text = "Hinhxanhla";
			// 
			// picBox_GREEN
			// 
			this.picBox_GREEN.Location = new System.Drawing.Point(65, 567);
			this.picBox_GREEN.Name = "picBox_GREEN";
			this.picBox_GREEN.Size = new System.Drawing.Size(512, 512);
			this.picBox_GREEN.TabIndex = 4;
			this.picBox_GREEN.TabStop = false;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(672, 547);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(94, 17);
			this.label5.TabIndex = 7;
			this.label5.Text = "Hinhxanhbien";
			// 
			// picBox_BLUE
			// 
			this.picBox_BLUE.Location = new System.Drawing.Point(675, 567);
			this.picBox_BLUE.Name = "picBox_BLUE";
			this.picBox_BLUE.Size = new System.Drawing.Size(512, 512);
			this.picBox_BLUE.TabIndex = 6;
			this.picBox_BLUE.TabStop = false;
			// 
			// Form1
			// 
			this.ClientSize = new System.Drawing.Size(1256, 1055);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.picBox_BLUE);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.picBox_GREEN);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.picBox_RED);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.picBox_Hinhgoc);
			this.Name = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.picBox_Hinhgoc)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.picBox_RED)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.picBox_GREEN)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.picBox_BLUE)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox picBox_Hinhgoc;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.PictureBox picBox_RED;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.PictureBox picBox_GREEN;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.PictureBox picBox_BLUE;
	}
}


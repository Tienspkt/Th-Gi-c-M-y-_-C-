﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tachnen01
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			// tạo 1 biến chưa đường dẫn
			// cần phải có @ trước
			string filehinh = @"C:\Users\HOME\Pictures\Camera Roll\lena.png";
			//tạo 1 biến chứa bitmap được load từ file
			Bitmap hinhgoc = new Bitmap(filehinh);
			//hiển thị hình gốc trong picbox đã tạo
			picBox_Hinhgoc.Image = hinhgoc;
			// khai báo 1 hình bitmap chứa 3 kênh màu
			Bitmap red = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			Bitmap green = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			Bitmap blue = new Bitmap(hinhgoc.Width, hinhgoc.Height);

			// mỗi hình là một ma trận 2 chiều nên sẽ dùng 2 vòng for
			//để đọc hiểu các điểm (pixel) có trong hình.
			for (int x = 0; x < hinhgoc.Width; x++)  // QUÉT THEO CHIỀU NGANG
				for (int y = 0; y < hinhgoc.Height; y++) // quét theo chiều dọc
				{
					// đọc giá trị pixel tại điểm ảnh có vị trí (x,y) nằm trong kiểu dữ liệu coror của Cshap
					Color pixel = hinhgoc.GetPixel(x, y);

					//mỗi pixel chứa 4 thông tin giá trị màu
					//R,G,B  và thông tin giá trị độ trong suốt A
					byte R = pixel.R; // giá trị kênh red
					byte G = pixel.G;// giá trị kênh green
					byte B = pixel.B;// giá trị kênh blue
					byte A = pixel.A;// độ trong suốt

					// set giá trị pixel đọc cho các hình chứa
					// các kênh màu tương ứng R.G,B
					red.SetPixel(x, y, Color.FromArgb(A, R, 0, 0));
					green.SetPixel(x, y, Color.FromArgb(A, 0, G, 0));
					blue.SetPixel(x, y, Color.FromArgb(A, 0, 0, B));
				}
			// hiển thị 3 hình kênh màu RGB
			picBox_RED.Image = red;
			picBox_GREEN.Image = green;
			picBox_BLUE.Image = blue;
		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}
	}
}

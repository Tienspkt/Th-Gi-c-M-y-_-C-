﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tachmauanh
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			string filehinh = @"C:\Users\HOME\Pictures\Camera Roll\lena.png";
			Bitmap Hinhgoc = new Bitmap(filehinh);
			picBox_Hnhgoc.Image = Hinhgoc;

		}

		
}

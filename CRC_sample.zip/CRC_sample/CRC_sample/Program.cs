﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRC_sample
{
	static class Program
	{
		static void Main()
		{
			
			byte slaveAddress = 1;
			byte functionCode = 3;
			ushort stratAddress = 0;
			ushort numberOfPoints = 2;

			// buid message fc03
			byte[] frame = new byte[8];
			frame[0] = slaveAddress;
			frame[1] = functionCode;
			frame[2] = (byte)(stratAddress >> 8);
			frame[3] = (byte)stratAddress;
			frame[4] = (byte)(numberOfPoints >> 8);
			frame[5] = (byte)numberOfPoints;
			byte[] checkSum = CRC16(frame);
			frame[6] = checkSum[0];
			frame[7] = checkSum[1];

			//print
			foreach (var item in frame)
			{
				Console.Write(string.Format("{0:X2} ", item));
			}
			Console.ReadKey();


		}

		private static byte[] CRC16(byte[] data)
		{
			byte[] checkSum = new byte[2];
			ushort reg_crc = 0XFFFF;
			for (int i =0; i < data.Length -2; i++)
			{
				reg_crc ^= data[i];
				for (int j = 0; j < 8; j++)
				{
					if ((reg_crc & 0x01) == 1)
					{
						reg_crc = (ushort)((reg_crc >> 1) ^ 0xA001);
					}
					else
					{
						reg_crc = (ushort)(reg_crc >> 1);
					}
				}
			}
			checkSum[1] = (byte)((reg_crc >> 8) & 0xFF);
			checkSum[0] = (byte)(reg_crc & 0xFF);
			return checkSum;
		} 

	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bt13
{
	public partial class Form1 : Form
	{
		Bitmap hinhgoc;
		int nguong;
		public Form1()
		{
			InitializeComponent();
			string filehinh = @"C:\Users\HOME\Pictures\Camera Roll\lena.png";
			hinhgoc = new Bitmap(filehinh);
			pictureBox_hinhgoc.Image = hinhgoc;

		}
		private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
		{
			// lấy giá trị ngưỡng từ thanh cuộn 
			nguong = vScrollBar1.Value;
			// cho hiển thị giá trị ngưỡng
			IbINGUONG.Text = nguong.ToString();

		}
		public Bitmap colorSegmentation(Bitmap hinhgoc)
		{
			//tinh vector mau trung binh
			int x1 = Convert.ToInt32(textBox_x1.Text);
			int y1 = Convert.ToInt32(textBox_y1.Text);
			int x2 = Convert.ToInt32(textBox_x2.Text);
			int y2 = Convert.ToInt32(textBox_y2.Text);
			

			double[] A = new double[3];
			A[0] = A[1] = A[2] = 0;
			for (int i = x1; i <= x2; i++)
				for (int j = y1; j <= y2; j++)
				{
					Color pixel = hinhgoc.GetPixel(i, j);
					A[0] += pixel.R;
					A[1] += pixel.G;
					A[2] += pixel.B;
				}
			double size = Math.Abs(x2 - x1) * Math.Abs(y2 - y1);
			double R_trungbinh = A[0] / size;
			double G_trungbinh = A[1] / size;
			double B_trungbinh = A[2] / size;

			//tinh Euclidean Distance
			Bitmap Segmentation = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			for (int x = 0; x < hinhgoc.Width; x++)
				for (int y = 0; y < hinhgoc.Height; y++)
				{
					Color Pixel = hinhgoc.GetPixel(x, y);
					double R = Pixel.R;
					double G = Pixel.G;
					double B = Pixel.B;

					double D = Math.Sqrt(Math.Pow((R - R_trungbinh), 2) + Math.Pow((G - G_trungbinh), 2) + Math.Pow((B - B_trungbinh), 2));
					if ((int)Math.Ceiling(D) <= nguong)
						Segmentation.SetPixel(x, y, Color.FromArgb(255, 255, 255));
					else
						Segmentation.SetPixel(x, y, Color.FromArgb((byte)R, (byte)G, (byte)B));

				}
			return Segmentation;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			pictureBox_phandoan.Image = colorSegmentation(hinhgoc);
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bt14
{
	public partial class Form1 : Form
	{
		Bitmap hinhgoc;//biến toàn cục 
		byte nguong;

		public Form1()
		{
			InitializeComponent();
			string filehinh = @"C:\Users\HOME\Pictures\Camera Roll\lena.png";
			hinhgoc = new Bitmap(filehinh);
			pictureBox_hinhgoc.Image = hinhgoc;
			pictureBox_nhandang.Image = GrayScale(hinhgoc);
		}

		public Bitmap GrayScale(Bitmap hinhgoc)
		{
			Bitmap GrayScale_img = new Bitmap(hinhgoc.Width, hinhgoc.Height);

			for (int x = 0; x < hinhgoc.Width; x++)
				for (int y = 0; y < hinhgoc.Height; y++)
				{
					Color pixel = hinhgoc.GetPixel(x, y);
					byte R = pixel.R;
					byte G = pixel.G;
					byte B = pixel.B;
					byte Gray = (byte)((R + G + B) / 3);

					GrayScale_img.SetPixel(x, y, Color.FromArgb(Gray, Gray, Gray));

				}
			return GrayScale_img;
		}
		private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
		{
			// ép giá trị int về byte 
			nguong = (byte)vScrollBar1.Value;
			// thể hiện giá trị lên label 
			label_nguong.Text = nguong.ToString();
			// cho hiển thị hình ảnh 

		}
		public Bitmap EdgeDetection(Bitmap GrayScale_img, byte nguong)
		{
			Bitmap EdgeDetection_img = new Bitmap(hinhgoc.Width, hinhgoc.Height);

			int[,] A = { { -1, -2, -1 }, { 0, 0, 0 }, { 1, 2, 1 } };
			int[,] B = { { -1, 0, 1 }, { -2, 0, 2 }, { -1, 0, 1 } };
			for (int x = 1; x < hinhgoc.Width - 1; x++)
				for (int y = 1; y < hinhgoc.Height - 1; y++)
				{
					double gx = 0; double gy = 0;
					for (int i = x - 1; i <= x + 1; i++)
						for (int j = y - 1; j <= y + 1; j++)
						{
							Color pixel = GrayScale_img.GetPixel(i, j);
							double r = pixel.R;

							gx += r * A[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];
							gy += r * B[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];

						}
					double M = Math.Abs(gx) + Math.Abs(gy);

					if ((byte)M <= nguong)
						EdgeDetection_img.SetPixel(x, y, Color.FromArgb(0, 0, 0));
					else
						EdgeDetection_img.SetPixel(x, y, Color.FromArgb(255, 255, 255));

				}
			return EdgeDetection_img;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Bitmap anhchuyendoi = EdgeDetection(hinhgoc,nguong);
			pictureBox_nhandang.Image = anhchuyendoi;
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bt15
{
	public partial class Form1 : Form
	{
		Bitmap hinhgoc;//biến toàn cục (global)
		byte nguong;
		public Form1()
		{
			InitializeComponent();
			string filehinh = @"C:\Users\HOME\Pictures\Camera Roll\lena.png";
			hinhgoc = new Bitmap(filehinh);
			pictureBox_hinhgoc.Image = hinhgoc;
			pictureBox_nhandang.Image = hinhgoc;
		}
		private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
		{
			nguong = (byte)vScrollBar1.Value;

			label_nguong.Text = nguong.ToString();
		}

		public Bitmap EdgeDetection(Bitmap hinhgoc, byte nguong)
		{
			Bitmap EdgeDetection_img = new Bitmap(hinhgoc.Width, hinhgoc.Height);

			int[,] S1 = { { -1, -2, -1 }, { 0, 0, 0 }, { 1, 2, 1 } };
			int[,] S2 = { { -1, 0, 1 }, { -2, 0, 2 }, { -1, 0, 1 } };
			for (int x = 1; x < hinhgoc.Width - 1; x++)
				for (int y = 1; y < hinhgoc.Height - 1; y++)
				{
					int gx_R = 0; int gy_R = 0;
					int gx_G = 0; int gy_G = 0;
					int gx_B = 0; int gy_B = 0;
					for (int i = x - 1; i <= x + 1; i++)
						for (int j = y - 1; j <= y + 1; j++)
						{
							Color pixel = hinhgoc.GetPixel(i, j);
							int R = pixel.R;
							int G = pixel.G;
							int B = pixel.B;

							gx_R += R * S1[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];
							gy_R += R * S2[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];

							gx_G += G * S1[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];
							gy_G += G * S2[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];

							gx_B += B * S1[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];
							gy_B += B * S2[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];

						}
					int gxx = (int)(Math.Pow(Math.Abs(gx_R), 2) + Math.Pow(Math.Abs(gx_G), 2) + Math.Pow(Math.Abs(gx_B), 2));
					int gyy = (int)(Math.Pow(Math.Abs(gy_R), 2) + Math.Pow(Math.Abs(gy_G), 2) + Math.Pow(Math.Abs(gy_B), 2));
					int gxy = gx_R * gy_R + gx_G * gy_G + gx_B * gy_B;

					int theta = (int)(Math.Atan2((2 * gxy), (gxx - gyy)) / 2);

					int F = (int)(Math.Sqrt(((gxx + gyy) + (gxx - gyy) * Math.Cos(2 * theta) + 2 * gxy * Math.Sin(2 * theta)) / 2));

					if (F < nguong)
						EdgeDetection_img.SetPixel(x, y, Color.FromArgb(0, 0, 0));
					else
						EdgeDetection_img.SetPixel(x, y, Color.FromArgb(255, 255, 255));

				}
			return EdgeDetection_img;
		}


		private void button1_Click(object sender, EventArgs e)
		{
			Bitmap anhchuyendoi = EdgeDetection(hinhgoc, nguong);
			pictureBox_nhandang.Image = anhchuyendoi;
		}


	}
}	




﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bt11
{
	public partial class Form1 : Form
	{
		
		public Form1()
		{
			InitializeComponent();
			// tạo 1 biến chưa đường dẫn
			// cần phải có @ trước
			string filehinh = @"C:\Users\HOME\Pictures\Camera Roll\lena.png";
			//tạo 1 biến chứa bitmap được load từ file
			 Bitmap hinhgoc = new Bitmap(filehinh);
			//hiển thị hình gốc trong picbox 
			pictureBox_hinhgoc.Image = hinhgoc;
			// cho hiển thị giá trị 
			Bitmap Lammuot3 = Lammuot3x3(hinhgoc);
			pictureBox_muot3.Image = Lammuot3;

			Bitmap Lammuot5 = Lammuot5x5(hinhgoc);
			pictureBox_muot5.Image = Lammuot5;

			Bitmap Lammuot7 = Lammuot7x7(hinhgoc);
			pictureBox_muot7.Image = Lammuot7;

			Bitmap Lammuot9 = Lammuot9x9(hinhgoc);
			pictureBox_muot9.Image = Lammuot9;

		}
		// viêt hàm mặt nạ 3x3
		public Bitmap Lammuot3x3 (Bitmap hinhgoc)
		{  // mặt nạ 3x3 để dễ lập trình bỏ qua phần viền ngoài 
			Bitmap muot3x3 = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			for (int x = 1; x<hinhgoc.Width-1;x++)
				for (int y = 1; y < hinhgoc.Height - 1; y++)
				{   // các biến chưa giá trị cộng dồn các điểm ảnh 
					int Rs = 0, Gs = 0, Bs = 0;

					for (int i = x-1; i<= x+1 ; i++)
						for (int j = y -1; j<= y+1; j++)
						{  // lấy giá trị RGB tại điểm ảnh trong mặt nạ tại vị trí (i ,j)
					
							Color color = hinhgoc.GetPixel(i, j);
							byte R = color.R;
							byte G = color.G;
							byte B = color.B;

							// Cộng dồn tất cả điểm ảnh đó cho mỗi kênh R ,G,B tương ứng 
							Rs += R;
							Gs += G;
							Bs += B;

						}
					// kết thúc quét và cộng dồn diemdr ảnh trong mặt nạ thì mình tính trung bình cho mỗi kênh 
					byte K = 3 * 3;
					Rs = (int)(Rs / K);
					Gs= (int)(Gs / K);
					Bs=(int)(Bs / K);

					// Set điểm ảnh đã làm mượt vào bitmap đã tạo
					muot3x3.SetPixel(x, y, Color.FromArgb(Rs, Gs, Bs));

				}
			return muot3x3;
		}
		public Bitmap Lammuot5x5(Bitmap hinhgoc)
		{  // mặt nạ 5x5 để dễ lập trình bỏ qua phần viền ngoài 
			Bitmap muot5x5 = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			for (int x = 2; x < hinhgoc.Width - 2; x++)
				for (int y = 2; y < hinhgoc.Height - 2; y++)
				{   // các biến chưa giá trị cộng dồn các điểm ảnh 
					int Rs = 0, Gs = 0, Bs = 0;

					for (int i = x - 2; i <= x + 2; i++)
						for (int j = y - 2; j <= y+2; j++)
						{  // lấy giá trị RGB tại điểm ảnh trong mặt nạ tại vị trí (i ,j)

							Color color = hinhgoc.GetPixel(i, j);
							byte R = color.R;
							byte G = color.G;
							byte B = color.B;

							// Cộng dồn tất cả điểm ảnh đó cho mỗi kênh R ,G,B tương ứng 
							Rs += R;
							Gs += G;
							Bs += B;

						}
					// kết thúc quét và cộng dồn diemdr ảnh trong mặt nạ thì mình tính trung bình cho mỗi kênh 
					byte K = 5 * 5;
					Rs = (int)(Rs / K);
					Gs = (int)(Gs / K);
					Bs = (int)(Bs / K);

					// Set điểm ảnh đã làm mượt vào bitmap đã tạo
					muot5x5.SetPixel(x, y, Color.FromArgb(Rs, Gs, Bs));

				}
			return muot5x5;
		}
		public Bitmap Lammuot7x7(Bitmap hinhgoc)
		{  // mặt nạ 7x7 để dễ lập trình bỏ qua phần viền ngoài 
			Bitmap muot7x7 = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			for (int x = 3; x < hinhgoc.Width - 3; x++)
				for (int y = 3; y < hinhgoc.Height - 3; y++)
				{   // các biến chưa giá trị cộng dồn các điểm ảnh 
					int Rs = 0, Gs = 0, Bs = 0;

					for (int i = x - 3; i <= x + 3; i++)
						for (int j = y - 3; j <= y+3; j++)
						{  // lấy giá trị RGB tại điểm ảnh trong mặt nạ tại vị trí (i ,j)

							Color color = hinhgoc.GetPixel(i, j);
							byte R = color.R;
							byte G = color.G;
							byte B = color.B;

							// Cộng dồn tất cả điểm ảnh đó cho mỗi kênh R ,G,B tương ứng 
							Rs += R;
							Gs += G;
							Bs += B;

						}
					// kết thúc quét và cộng dồn diemdr ảnh trong mặt nạ thì mình tính trung bình cho mỗi kênh 
					byte K = 7 * 7;
					Rs = (int)(Rs / K);
					Gs = (int)(Gs / K);
					Bs = (int)(Bs / K);

					// Set điểm ảnh đã làm mượt vào bitmap đã tạo
					muot7x7.SetPixel(x, y, Color.FromArgb(Rs, Gs, Bs));

				}
			return muot7x7;
		}
		public Bitmap Lammuot9x9(Bitmap hinhgoc)
		{  // mặt nạ 9x9 để dễ lập trình bỏ qua phần viền ngoài 
			Bitmap muot9x9 = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			for (int x = 4; x < hinhgoc.Width - 4; x++)
				for (int y = 4; y < hinhgoc.Height - 4; y++)
				{   // các biến chưa giá trị cộng dồn các điểm ảnh 
					int Rs = 0, Gs = 0, Bs = 0;

					for (int i = x - 4; i <= x + 4; i++)
						for (int j = y - 4; j <= y + 4; j++)
						{  // lấy giá trị RGB tại điểm ảnh trong mặt nạ tại vị trí (i ,j)

							Color color = hinhgoc.GetPixel(i, j);
							byte R = color.R;
							byte G = color.G;
							byte B = color.B;

							// Cộng dồn tất cả điểm ảnh đó cho mỗi kênh R ,G,B tương ứng 
							Rs += R;
							Gs += G;
							Bs += B;

						}
					// kết thúc quét và cộng dồn diemdr ảnh trong mặt nạ thì mình tính trung bình cho mỗi kênh 
					byte K = 9 * 9;
					Rs = (int)(Rs / K);
					Gs = (int)(Gs / K);
					Bs = (int)(Bs / K);

					// Set điểm ảnh đã làm mượt vào bitmap đã tạo
					muot9x9.SetPixel(x, y, Color.FromArgb(Rs, Gs, Bs));

				}
			return muot9x9;
		}
	}
}
	


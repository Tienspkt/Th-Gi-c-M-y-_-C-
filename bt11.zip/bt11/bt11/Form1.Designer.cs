﻿namespace bt11
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lb_hinhgoc = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.pictureBox_muot5 = new System.Windows.Forms.PictureBox();
			this.label3 = new System.Windows.Forms.Label();
			this.pictureBox_muot7 = new System.Windows.Forms.PictureBox();
			this.label4 = new System.Windows.Forms.Label();
			this.pictureBox_muot9 = new System.Windows.Forms.PictureBox();
			this.pictureBox_hinhgoc = new System.Windows.Forms.PictureBox();
			this.pictureBox_muot3 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_muot5)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_muot7)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_muot9)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_hinhgoc)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_muot3)).BeginInit();
			this.SuspendLayout();
			// 
			// lb_hinhgoc
			// 
			this.lb_hinhgoc.AutoSize = true;
			this.lb_hinhgoc.Location = new System.Drawing.Point(9, 15);
			this.lb_hinhgoc.Name = "lb_hinhgoc";
			this.lb_hinhgoc.Size = new System.Drawing.Size(71, 17);
			this.lb_hinhgoc.TabIndex = 1;
			this.lb_hinhgoc.Text = "Hình Gốc ";
			this.lb_hinhgoc.UseWaitCursor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(9, 487);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 17);
			this.label1.TabIndex = 3;
			this.label1.Text = "Mượt 3*3";
			this.label1.UseWaitCursor = true;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(482, 487);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(64, 17);
			this.label2.TabIndex = 5;
			this.label2.Text = "Mượt 5*5";
			this.label2.UseWaitCursor = true;
			// 
			// pictureBox_muot5
			// 
			this.pictureBox_muot5.Location = new System.Drawing.Point(485, 507);
			this.pictureBox_muot5.Name = "pictureBox_muot5";
			this.pictureBox_muot5.Size = new System.Drawing.Size(450, 450);
			this.pictureBox_muot5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_muot5.TabIndex = 4;
			this.pictureBox_muot5.TabStop = false;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(956, 487);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(64, 17);
			this.label3.TabIndex = 7;
			this.label3.Text = "Mượt 7*7";
			this.label3.UseWaitCursor = true;
			// 
			// pictureBox_muot7
			// 
			this.pictureBox_muot7.Location = new System.Drawing.Point(959, 507);
			this.pictureBox_muot7.Name = "pictureBox_muot7";
			this.pictureBox_muot7.Size = new System.Drawing.Size(450, 450);
			this.pictureBox_muot7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_muot7.TabIndex = 6;
			this.pictureBox_muot7.TabStop = false;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(1423, 487);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(64, 17);
			this.label4.TabIndex = 9;
			this.label4.Text = "Mượt 9*9";
			this.label4.UseWaitCursor = true;
			// 
			// pictureBox_muot9
			// 
			this.pictureBox_muot9.Location = new System.Drawing.Point(1426, 507);
			this.pictureBox_muot9.Name = "pictureBox_muot9";
			this.pictureBox_muot9.Size = new System.Drawing.Size(450, 450);
			this.pictureBox_muot9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_muot9.TabIndex = 8;
			this.pictureBox_muot9.TabStop = false;
			// 
			// pictureBox_hinhgoc
			// 
			this.pictureBox_hinhgoc.Location = new System.Drawing.Point(12, 35);
			this.pictureBox_hinhgoc.Name = "pictureBox_hinhgoc";
			this.pictureBox_hinhgoc.Size = new System.Drawing.Size(459, 424);
			this.pictureBox_hinhgoc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_hinhgoc.TabIndex = 10;
			this.pictureBox_hinhgoc.TabStop = false;
			// 
			// pictureBox_muot3
			// 
			this.pictureBox_muot3.Location = new System.Drawing.Point(12, 516);
			this.pictureBox_muot3.Name = "pictureBox_muot3";
			this.pictureBox_muot3.Size = new System.Drawing.Size(459, 441);
			this.pictureBox_muot3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_muot3.TabIndex = 11;
			this.pictureBox_muot3.TabStop = false;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1907, 975);
			this.Controls.Add(this.pictureBox_muot3);
			this.Controls.Add(this.pictureBox_hinhgoc);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.pictureBox_muot9);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.pictureBox_muot7);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.pictureBox_muot5);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lb_hinhgoc);
			this.Name = "Form1";
			this.Text = "Form1";
			this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_muot5)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_muot7)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_muot9)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_hinhgoc)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_muot3)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Label lb_hinhgoc;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.PictureBox pictureBox_muot5;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.PictureBox pictureBox_muot7;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.PictureBox pictureBox_muot9;
		private System.Windows.Forms.PictureBox pictureBox_hinhgoc;
		private System.Windows.Forms.PictureBox pictureBox_muot3;
	}
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bt09
{
	public partial class Form1 : Form
	{
		Bitmap hinhgoc;
		public Form1()
		{
			InitializeComponent();
			// tạo 1 biến chưa đường dẫn
			// cần phải có @ trước
			string filehinh = @"C:\Users\HOME\Pictures\Camera Roll\lena.png";
			//tạo 1 biến chứa bitmap được load từ file
			 hinhgoc = new Bitmap(filehinh);
			//hiển thị hình gốc trong picbox 
			pictureBox_hinhgoc.Image = hinhgoc;
			List<Bitmap> HSV = ChuyenDoiRGBSangXYZ(hinhgoc);
			pictureBox_X.Image = HSV[0];
			pictureBox_Y.Image = HSV[1];
			pictureBox_Z.Image = HSV[2];
			

		}
		public List<Bitmap> ChuyenDoiRGBSangXYZ(Bitmap hinhgoc)
		{   // Tạo mangr chứ kết quả  
			List<Bitmap> XYZ = new List<Bitmap>();
			//Tạo 3 kênh màu chứ kênh ZYZ
			Bitmap Kenh_X = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			Bitmap Kenh_Y = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			Bitmap Kenh_Z = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			// tổng hợp 3 kênh trên 
			Bitmap Kenh_XYZ = new Bitmap(hinhgoc.Width, hinhgoc.Height);

			for (int x = 0; x < hinhgoc.Width; x++)  // QUÉT THEO CHIỀU NGANG
				for (int y = 0; y < hinhgoc.Height; y++) // quét theo chiều dọc
				{
					// đọc giá trị pixel tại điểm ảnh có vị trí (x,y) nằm trong kiểu dữ liệu coror của Cshap
					Color pixel = hinhgoc.GetPixel(x, y);

					//mỗi pixel chứa 4 thông tin giá trị màu
					//R,G,B  và thông tin giá trị độ trong suốt A , đổi kiểu : double 
					double R = pixel.R; // giá trị kênh red
					double G = pixel.G;// giá trị kênh green
					double B = pixel.B;// giá trị kênh blue
									   // công thức tính 

					double X = 0.4124564 * R + 0.3575761 * G + 0.1804375 * B;
					double Y = 0.2126729 * R + 0.7151522 * G + 0.0721750 * B;
					double Z = 0.0193339 * R + 0.1191920 * G + 0.9503041 * B;





					//  cho hiển thịc lên các kênh giá trị và ép về kểu Byte 
					Kenh_X.SetPixel(x, y, Color.FromArgb((byte)X, (byte)X, (byte)X));
					//giá trị kểu S
					Kenh_Y.SetPixel(x, y, Color.FromArgb((byte)Y, (byte)Y, (byte)Y));
					Kenh_Z.SetPixel(x, y, Color.FromArgb((byte)Z, (byte)Z, (byte)Z));
					// giá trị tổng hợp 
					Kenh_XYZ.SetPixel(x, y, Color.FromArgb((byte)X, (byte)Y, (byte)Z));


				}
			XYZ.Add(Kenh_X);
			XYZ.Add(Kenh_Y);
			XYZ.Add(Kenh_Z);
			XYZ.Add(Kenh_XYZ);
			return XYZ;
		}

		private void button1_click(object sender, EventArgs e)
		{
			List<Bitmap> XYZ = ChuyenDoiRGBSangXYZ(hinhgoc);
			pictureBox_XYZ.Image = XYZ[3];
		}
	}
}

		
	


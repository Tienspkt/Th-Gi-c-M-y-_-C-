﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bt12
{   
	public partial class Form1 : Form
	{
		Bitmap hinhgoc;
		public Form1()
		{
			InitializeComponent();
			string filehinh = @"C:\Users\HOME\Pictures\Camera Roll\lena.png";
			hinhgoc = new Bitmap(filehinh);
			pictureBox_HinhGoc.Image = hinhgoc;
			pictureBox_Lamnet.Image = hinhgoc;

		}

		public Bitmap Sharpening(Bitmap hinhgoc)
		{
			Bitmap SharpeningImage = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			int[,] A = { { 0, -1, 0 }, { -1, 4, -1 }, { 0, -1, 0 } };

			for (int x = 1; x < hinhgoc.Width - 1; x++)
				for (int y = 1; y < hinhgoc.Height - 1; y++)
				{
					int Rs = 0, Bs = 0, Gs = 0;
					int R_Laplacian = 0, B_Laplacian = 0, G_Laplacian = 0;

					for (int i = x - 1; i <= x + 1; i++)
						for (int j = y - 1; j <= y + 1; j++)
						{
							Color Pixel = hinhgoc.GetPixel(i, j);
							int r = Pixel.R;
							int g = Pixel.G;
							int b = Pixel.B;

							R_Laplacian += r * A[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];
							G_Laplacian += g * A[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];
							B_Laplacian += b * A[Math.Abs(x - i - 1), Math.Abs(y - j - 1)];

						}
					Color pixel = hinhgoc.GetPixel(x, y);
					int R = pixel.R;
					int G = pixel.G;
					int B = pixel.B;

					Rs = (int)(R_Laplacian + R);
					Gs = (int)(G_Laplacian + G);
					Bs = (int)(B_Laplacian + B);

					if (Bs < 0)
						Bs = 0;
					else if (Bs > 255)
						Bs = 255;

					if (Rs < 0)
						Rs = 0;
					else if (Rs > 255)
						Rs = 255;

					if (Gs < 0)
						Gs = 0;
					else if (Gs > 255)
						Gs = 255;

					SharpeningImage.SetPixel(x, y, Color.FromArgb(Rs, Gs, Bs));

				}
			return SharpeningImage;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Bitmap hinhlammuot33 = Sharpening(hinhgoc);
			pictureBox_Lamnet.Image = hinhlammuot33;
		}
	}
}



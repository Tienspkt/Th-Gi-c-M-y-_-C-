﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bt10
{
	public partial class Form1 : Form
	{
		Bitmap hinhgoc;
		public Form1()
		{
			InitializeComponent();
			// tạo 1 biến chưa đường dẫn
			// cần phải có @ trước
			string filehinh = @"C:\Users\HOME\Pictures\Camera Roll\lena.png";
			//tạo 1 biến chứa bitmap được load từ file
			hinhgoc = new Bitmap(filehinh);
			//hiển thị hình gốc trong picbox 
			pictureBox_HinhGoc.Image = hinhgoc;
			List<Bitmap> HSV = ChuyenDoiRGBSangXYZ(hinhgoc);
			pictureBox_Y.Image = HSV[0];
			pictureBox_Cb.Image = HSV[1];
			pictureBox_Cr.Image = HSV[2];


		}
		public List<Bitmap> ChuyenDoiRGBSangXYZ(Bitmap hinhgoc)
		{   // Tạo mangr chứ kết quả  
			List<Bitmap> YCbCr = new List<Bitmap>();
			//Tạo 3 kênh màu chứ kênh ZYZ
			Bitmap Kenh_Y = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			Bitmap Kenh_Cb = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			Bitmap Kenh_Cr = new Bitmap(hinhgoc.Width, hinhgoc.Height);
			// tổng hợp 3 kênh trên 
			Bitmap Kenh_YCbCr = new Bitmap(hinhgoc.Width, hinhgoc.Height);

			for (int x = 0; x < hinhgoc.Width; x++)  // QUÉT THEO CHIỀU NGANG
				for (int y = 0; y < hinhgoc.Height; y++) // quét theo chiều dọc
				{
					// đọc giá trị pixel tại điểm ảnh có vị trí (x,y) nằm trong kiểu dữ liệu coror của Cshap
					Color pixel = hinhgoc.GetPixel(x, y);

					//mỗi pixel chứa 4 thông tin giá trị màu
					//R,G,B  và thông tin giá trị độ trong suốt A , đổi kiểu : double 
					double R = pixel.R; // giá trị kênh red
					double G = pixel.G;// giá trị kênh green
					double B = pixel.B;// giá trị kênh blue
									   // công thức tính 

					double Y = (16+( 65.738*R + 129.057*G + 25.064*B)/255);
					double Cb = (128-(37.945* R - 74.494*G + 112.439*B)/255);
					double Cr = (128+(112.439* R - 94.154*G + 18.285* B)/255);


					//  cho hiển thịc lên các kênh giá trị và ép về kểu Byte 
					Kenh_Y.SetPixel(x, y, Color.FromArgb((byte)Y, (byte)Y, (byte)Y));
					//giá trị kểu S
					Kenh_Cb.SetPixel(x, y, Color.FromArgb((byte)Cb, (byte)Cb, (byte)Cb));
					Kenh_Cr.SetPixel(x, y, Color.FromArgb((byte)Cr, (byte)Cr, (byte)Cr));
					// giá trị tổng hợp 
					Kenh_YCbCr.SetPixel(x, y, Color.FromArgb((byte)Y, (byte)Cb, (byte)Cr));


				}
			YCbCr.Add(Kenh_Y);
			YCbCr.Add(Kenh_Cb);
			YCbCr.Add(Kenh_Cr);
			YCbCr.Add(Kenh_YCbCr);
			return YCbCr;
		}

		private void button1_click(object sender, EventArgs e)
		{
			List<Bitmap> YCbCr = ChuyenDoiRGBSangXYZ(hinhgoc);
			pictureBox_TongHop.Image = YCbCr[3];
		}
	}
}





﻿namespace Bt15
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox_hinhgoc = new System.Windows.Forms.PictureBox();
			this.pictureBox_nhandang = new System.Windows.Forms.PictureBox();
			this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label_nguong = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_hinhgoc)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_nhandang)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox_hinhgoc
			// 
			this.pictureBox_hinhgoc.Location = new System.Drawing.Point(42, 42);
			this.pictureBox_hinhgoc.Name = "pictureBox_hinhgoc";
			this.pictureBox_hinhgoc.Size = new System.Drawing.Size(512, 512);
			this.pictureBox_hinhgoc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_hinhgoc.TabIndex = 0;
			this.pictureBox_hinhgoc.TabStop = false;
			// 
			// pictureBox_nhandang
			// 
			this.pictureBox_nhandang.Location = new System.Drawing.Point(588, 42);
			this.pictureBox_nhandang.Name = "pictureBox_nhandang";
			this.pictureBox_nhandang.Size = new System.Drawing.Size(512, 512);
			this.pictureBox_nhandang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_nhandang.TabIndex = 1;
			this.pictureBox_nhandang.TabStop = false;
			// 
			// vScrollBar1
			// 
			this.vScrollBar1.Location = new System.Drawing.Point(1155, 209);
			this.vScrollBar1.Maximum = 200;
			this.vScrollBar1.Minimum = 50;
			this.vScrollBar1.Name = "vScrollBar1";
			this.vScrollBar1.Size = new System.Drawing.Size(46, 345);
			this.vScrollBar1.TabIndex = 2;
			this.vScrollBar1.Value = 50;
			this.vScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBar1_Scroll);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(39, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(71, 17);
			this.label1.TabIndex = 3;
			this.label1.Text = "Hình Gốc ";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(585, 22);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(114, 17);
			this.label2.TabIndex = 4;
			this.label2.Text = "Hình chuyển đổi ";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(1155, 180);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(62, 17);
			this.label3.TabIndex = 5;
			this.label3.Text = "Ngưỡng ";
			// 
			// label_nguong
			// 
			this.label_nguong.AutoSize = true;
			this.label_nguong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label_nguong.Location = new System.Drawing.Point(1230, 209);
			this.label_nguong.Name = "label_nguong";
			this.label_nguong.Size = new System.Drawing.Size(71, 20);
			this.label_nguong.TabIndex = 6;
			this.label_nguong.Text = "Ngưỡng ";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(1278, 487);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(128, 67);
			this.button1.TabIndex = 7;
			this.button1.Text = "Nhận dạng đường biên ";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1578, 703);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label_nguong);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.vScrollBar1);
			this.Controls.Add(this.pictureBox_nhandang);
			this.Controls.Add(this.pictureBox_hinhgoc);
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_hinhgoc)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_nhandang)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox_hinhgoc;
		private System.Windows.Forms.PictureBox pictureBox_nhandang;
		private System.Windows.Forms.VScrollBar vScrollBar1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label_nguong;
		private System.Windows.Forms.Button button1;
	}
}

